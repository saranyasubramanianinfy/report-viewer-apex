import { LightningElement, track } from 'lwc';
import getAvailableReports from '@salesforce/apex/ReportViewerController.getAvailableReports';
import runReport from '@salesforce/apex/ReportViewerController.runReport';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class ReportViewer extends LightningElement {

    @track reportOptions = [];
    selectedReport;
    columns;
    tableColumns = [];
    tableData = [];

    connectedCallback() {
        this.loadReports();
    }

    loadReports() {
        getAvailableReports()
            .then(data => {
                this.reportOptions = data.map(r => ({
                    label: r.reportName,
                    value: r.reportId
                }));
            })
            .catch(error => {
                this.showError(error.body.message);
            });
    }

    handleChange(event) {
        this.selectedReport = event.detail.value;
    }

    runReport() {
        runReport({ reportId: this.selectedReport })
            .then(result => {
                this.columns = result.columns;
                this.prepareTable(result);
                this.sendDataToVF(result);
            })
            .catch(error => {
                this.showError(error.body.message);
            });
    }

    prepareTable(result) {
        this.tableColumns = result.columns.map(col => ({
            label: col,
            fieldName: col
        }));

        this.tableData = result.rows.map((row, index) => {
            let obj = { id: index };
            result.columns.forEach((col, i) => {
                obj[col] = row[i];
            });
            return obj;
        });
    }

    sendDataToVF(data) {
        if (window.parent?.receiveReportData) {
            window.parent.receiveReportData(JSON.stringify(data));
        }
    }

    showError(message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message,
                variant: 'error'
            })
        );
    }
}